class Mascotas {
  String foto;
  String nombre;
  String raza;
  String edad;
  String id;

  Mascotas(this.foto, this.nombre, this.raza, this.edad, this.id);
}


