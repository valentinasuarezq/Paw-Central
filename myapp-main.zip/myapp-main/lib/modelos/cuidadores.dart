class CuidadoresModel {
  String foto;
  String nombre;
  String profesion;
  String edad;
  String id;

  CuidadoresModel(this.foto, this.nombre, this.profesion, this.edad, this.id);
}

